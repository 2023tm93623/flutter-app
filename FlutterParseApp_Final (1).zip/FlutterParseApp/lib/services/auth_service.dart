import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import '../models/user_model.dart';

class AuthService {
  // Sign up a new user
  Future<UserModel> signUp(String username, String email, String password) async {
    final user = ParseUser.createUser(username, password, email);
    
    final response = await user.signUp();
    
    if (response.success) {
      return UserModel.fromParseUser(user);
    } else {
      throw Exception(response.error?.message ?? 'Failed to sign up');
    }
  }
  
  // Log in an existing user
  Future<UserModel> login(String username, String password) async {
    final user = ParseUser(username, password, null);
    
    final response = await user.login();
    
    if (response.success) {
      return UserModel.fromParseUser(user);
    } else {
      throw Exception(response.error?.message ?? 'Failed to log in');
    }
  }
  
  // Log out the current user
  Future<void> logout() async {
    final user = await ParseUser.currentUser() as ParseUser;
    final response = await user.logout();
    
    if (!response.success) {
      throw Exception(response.error?.message ?? 'Failed to log out');
    }
  }
  
  // Reset password
  Future<void> resetPassword(String email) async {
    final user = ParseUser(null, null, email);
    
    final response = await user.requestPasswordReset();
    
    if (!response.success) {
      throw Exception(response.error?.message ?? 'Failed to reset password');
    }
  }
  
  // Get current user - with fixes to prevent repeated API calls
Future<UserModel?> getCurrentUser() async {
  try {
    // First check if we have a stored user
    final user = await ParseUser.currentUser() as ParseUser?;
    
    if (user == null) {
      return null;
    }
    
    // Only check with server if we have a valid session token and haven't checked recently
    if (user.sessionToken != null) {
      // We already have user data locally, so return it without server check
      return UserModel.fromParseUser(user);
    }
    
    return null;
  } catch (e) {
    return null;
  }
}
  
  // Check if user is logged in
  Future<bool> isLoggedIn() async {
    final user = await ParseUser.currentUser() as ParseUser?;
    
    if (user == null || user.sessionToken == null) {
      return false;
    }
    
    try {
      // Only validate the token once to avoid multiple API calls
      final response = await ParseUser.getCurrentUserFromServer(user.sessionToken!);
      return response!.success;
    } catch (e) {
      return false;
    }
  }
}
