import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import '../models/record_model.dart';
import '../utils/constants.dart';

class RecordService {
  // Create a new record
  Future<RecordModel> createRecord(String name, int age) async {
    final currentUser = await ParseUser.currentUser() as ParseUser;
    
    final record = ParseObject(kRecordClassName)
      ..set(kRecordNameField, name)
      ..set(kRecordAgeField, age)
      ..set(kRecordUserField, currentUser);
    
    final response = await record.save();
    
    if (response.success && response.result != null) {
      return RecordModel.fromParseObject(response.result);
    } else {
      throw Exception(response.error?.message ?? 'Failed to create record');
    }
  }
  
 // Get all records for the current user
Future<List<RecordModel>> getAllRecords() async {
  try {
    // Check if we have a current user first
    final currentUser = await ParseUser.currentUser() as ParseUser?;
    
    if (currentUser == null || currentUser.objectId == null) {
      // No user or invalid user, return empty list instead of hanging
      return [];
    }
    
    final query = QueryBuilder(ParseObject(kRecordClassName))
      ..whereEqualTo(kRecordUserField, currentUser)
      ..orderByDescending('createdAt');
    
    final response = await query.query();
    
    if (response.success && response.results != null) {
      return response.results!
          .map((record) => RecordModel.fromParseObject(record as ParseObject))
          .toList();
    } else {
      throw Exception(response.error?.message ?? 'Failed to fetch records');
    }
  } catch (e) {
    // Log the error and return empty list to avoid hanging
    print('Error fetching records: $e');
    return [];
  }
}
  // Get a single record by ID
  Future<RecordModel> getRecordById(String objectId) async {
    final query = QueryBuilder(ParseObject(kRecordClassName))
      ..whereEqualTo('objectId', objectId);
    
    final response = await query.query();
    
    if (response.success && response.results != null && response.results!.isNotEmpty) {
      return RecordModel.fromParseObject(response.results!.first as ParseObject);
    } else {
      throw Exception(response.error?.message ?? 'Record not found');
    }
  }
  
  // Update an existing record
  Future<RecordModel> updateRecord(String objectId, String name, int age) async {
    final record = ParseObject(kRecordClassName)
      ..objectId = objectId
      ..set(kRecordNameField, name)
      ..set(kRecordAgeField, age);
    
    final response = await record.save();
    
    if (response.success && response.result != null) {
      return RecordModel.fromParseObject(response.result);
    } else {
      throw Exception(response.error?.message ?? 'Failed to update record');
    }
  }
  
  // Delete a record
  Future<void> deleteRecord(String objectId) async {
    final record = ParseObject(kRecordClassName)..objectId = objectId;
    
    final response = await record.delete();
    
    if (!response.success) {
      throw Exception(response.error?.message ?? 'Failed to delete record');
    }
  }
}
