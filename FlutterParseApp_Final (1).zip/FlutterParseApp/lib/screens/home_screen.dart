import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

import '../providers/auth_provider.dart';
import '../providers/record_provider.dart';
import '../widgets/record_item.dart';
import 'add_record_screen.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  static const routeName = '/home';

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _isInit = true;
  
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    
    if (_isInit) {
      _fetchRecords();
      _isInit = false;
    }
  }
  
  Future<void> _fetchRecords() async {
    await Provider.of<RecordProvider>(context, listen: false).fetchRecords();
  }
  
  Future<void> _logout() async {
    await Provider.of<AuthProvider>(context, listen: false).logout();
    Navigator.of(context).pushReplacementNamed(LoginScreen.routeName);
  }
  
  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
  
  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
Widget build(BuildContext context) {
  final authProvider = Provider.of<AuthProvider>(context);
  final recordProvider = Provider.of<RecordProvider>(context);
  final records = recordProvider.records;
  final isLoading = recordProvider.isLoading;
  final hasError = recordProvider.status == RecordStatus.Error;
  
  // Add this to debug
  print("Home Screen Build - isLoading: $isLoading, records count: ${records.length}");
  
  if (hasError) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _showErrorSnackBar(recordProvider.errorMessage ?? 'Failed to load records');
      recordProvider.clearError();
    });
  }
    
    return Scaffold(
      appBar: AppBar(
        title: Text('Records'),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: _logout,
            tooltip: 'Logout',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _fetchRecords,
        child: isLoading
            ? Center(
                child: SpinKitCircle(
                  color: Theme.of(context).primaryColor,
                  size: 50.0,
                ),
              )
            : records.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.note_alt_outlined,
                          size: 80,
                          color: Colors.grey[400],
                        ),
                        SizedBox(height: 16),
                        Text(
                          'No records found',
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.grey[600],
                          ),
                        ),
                        SizedBox(height: 8),
                        Text(
                          'Add a new record using the + button',
                          style: TextStyle(
                            color: Colors.grey[500],
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: EdgeInsets.all(16),
                    itemCount: records.length,
                    itemBuilder: (ctx, index) {
                      final record = records[index];
                      
                      return RecordItem(
                        record: record,
                        onDeleted: () {
                          _showSuccessSnackBar('Record deleted successfully');
                        },
                      );
                    },
                  ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (ctx) => AddRecordScreen(
                onRecordAdded: () {
                  _showSuccessSnackBar('Record added successfully');
                },
              ),
            ),
          );
        },
        child: Icon(Icons.add),
        tooltip: 'Add Record',
      ),
    );
  }
}
