import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

import '../models/record_model.dart';
import '../providers/record_provider.dart';
import '../utils/validators.dart';

class EditRecordScreen extends StatefulWidget {
  final RecordModel record;
  final Function? onRecordUpdated;
  
  const EditRecordScreen({
    Key? key,
    required this.record,
    this.onRecordUpdated,
  }) : super(key: key);

  @override
  _EditRecordScreenState createState() => _EditRecordScreenState();
}

class _EditRecordScreenState extends State<EditRecordScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _ageController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.record.name);
    _ageController = TextEditingController(text: widget.record.age.toString());
  }

  @override
  void dispose() {
    _nameController.dispose();
    _ageController.dispose();
    super.dispose();
  }

  Future<void> _updateRecord() async {
  if (!_formKey.currentState!.validate()) {
    return;
  }

  final recordProvider = Provider.of<RecordProvider>(context, listen: false);
  
  final age = int.parse(_ageController.text.trim());
  
  final success = await recordProvider.updateRecord(
    widget.record.objectId,
    _nameController.text.trim(),
    age,
  );
  
 if (success && mounted) {
  // After successful update, refresh the records list
  await recordProvider.fetchRecords();
  
  if (widget.onRecordUpdated != null) {
    Navigator.of(context).pop(); // Pop first
    widget.onRecordUpdated!(); // Then call callback after navigation completed
  } else {
    Navigator.of(context).pop();
  }
}
}

  @override
  Widget build(BuildContext context) {
    final recordProvider = Provider.of<RecordProvider>(context);
    final isLoading = recordProvider.isLoading;
    final hasError = recordProvider.status == RecordStatus.Error;
    
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Record'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Error message if update failed
              if (hasError)
                Container(
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                  margin: EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.red[50],
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.red.shade200),
                  ),
                  child: Text(
                    recordProvider.errorMessage ?? 'Failed to update record',
                    style: TextStyle(color: Colors.red[800]),
                  ),
                ),
              
              // Name field
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Name',
                  hintText: 'Enter person name',
                  border: OutlineInputBorder(),
                ),
                validator: Validators.validateName,
                enabled: !isLoading,
                textInputAction: TextInputAction.next,
              ),
              
              SizedBox(height: 16),
              
              // Age field
              TextFormField(
                controller: _ageController,
                decoration: InputDecoration(
                  labelText: 'Age',
                  hintText: 'Enter age (number only)',
                  border: OutlineInputBorder(),
                ),
                validator: Validators.validateAge,
                enabled: !isLoading,
                keyboardType: TextInputType.number,
                textInputAction: TextInputAction.done,
                onFieldSubmitted: (_) => _updateRecord(),
              ),
              
              SizedBox(height: 24),
              
              // Update button
              SizedBox(
                height: 50,
                child: ElevatedButton(
                  onPressed: isLoading ? null : _updateRecord,
                  child: isLoading
                      ? SpinKitThreeBounce(
                          color: Colors.white,
                          size: 24,
                        )
                      : Text(
                          'UPDATE',
                          style: TextStyle(fontSize: 16),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
