import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

import '../providers/record_provider.dart';
import '../utils/validators.dart';

class AddRecordScreen extends StatefulWidget {
  final Function? onRecordAdded;
  
  const AddRecordScreen({Key? key, this.onRecordAdded}) : super(key: key);

  @override
  _AddRecordScreenState createState() => _AddRecordScreenState();
}

class _AddRecordScreenState extends State<AddRecordScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _ageController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    _ageController.dispose();
    super.dispose();
  }

  Future<void> _saveRecord() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    final recordProvider = Provider.of<RecordProvider>(context, listen: false);
    
    final age = int.parse(_ageController.text.trim());
    
    final success = await recordProvider.addRecord(
      _nameController.text.trim(),
      age,
    );
    
    if (success && mounted) {
      if (widget.onRecordAdded != null) {
        widget.onRecordAdded!();
      }
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final recordProvider = Provider.of<RecordProvider>(context);
    final isLoading = recordProvider.isLoading;
    final hasError = recordProvider.status == RecordStatus.Error;
    
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Record'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Error message if add failed
              if (hasError)
                Container(
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                  margin: EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.red[50],
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.red.shade200),
                  ),
                  child: Text(
                    recordProvider.errorMessage ?? 'Failed to add record',
                    style: TextStyle(color: Colors.red[800]),
                  ),
                ),
              
              // Name field
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Name',
                  hintText: 'Enter person name',
                  border: OutlineInputBorder(),
                ),
                validator: Validators.validateName,
                enabled: !isLoading,
                textInputAction: TextInputAction.next,
              ),
              
              SizedBox(height: 16),
              
              // Age field
              TextFormField(
                controller: _ageController,
                decoration: InputDecoration(
                  labelText: 'Age',
                  hintText: 'Enter age (number only)',
                  border: OutlineInputBorder(),
                ),
                validator: Validators.validateAge,
                enabled: !isLoading,
                keyboardType: TextInputType.number,
                textInputAction: TextInputAction.done,
                onFieldSubmitted: (_) => _saveRecord(),
              ),
              
              SizedBox(height: 24),
              
              // Save button
              SizedBox(
                height: 50,
                child: ElevatedButton(
                  onPressed: isLoading ? null : _saveRecord,
                  child: isLoading
                      ? SpinKitThreeBounce(
                          color: Colors.white,
                          size: 24,
                        )
                      : Text(
                          'SAVE',
                          style: TextStyle(fontSize: 16),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
