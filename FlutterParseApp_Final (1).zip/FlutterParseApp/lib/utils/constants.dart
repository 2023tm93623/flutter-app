// Back4App Parse Server Configuration
const String kParseApplicationId = 'ZwGXQZS4mpaHqZWRU6lkyZcOViZZM3iNRIXx84dA';
const String kParseClientKey = 'z2e0uUcFbkg0oqlKDeGItPll87lxHvtaNmWqtiOz';
const String kParseServerUrl = 'https://parseapi.back4app.com';

// Parse Object Names
const String kUserClassName = '_User';
const String kRecordClassName = 'Record';

// Record Field Names
const String kRecordNameField = 'name';
const String kRecordAgeField = 'age';
const String kRecordUserField = 'user';

// Error Messages
const String kGenericErrorMessage = 'Something went wrong. Please try again.';
const String kNetworkErrorMessage = 'Network error. Please check your connection.';
const String kAuthErrorMessage = 'Authentication failed. Please check your credentials.';
const String kRequiredFieldMessage = 'This field is required';
const String kInvalidEmailMessage = 'Please enter a valid email address';
const String kInvalidAgeMessage = 'Age must be a number';
const String kPasswordMismatchMessage = 'Passwords do not match';
const String kPasswordLengthMessage = 'Password must be at least 6 characters';
