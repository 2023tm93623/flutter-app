import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

class UserModel {
  final String objectId;
  final String email;
  final String username;
  final DateTime createdAt;
  final DateTime updatedAt;

  UserModel({
    required this.objectId,
    required this.email,
    required this.username,
    required this.createdAt,
    required this.updatedAt,
  });

  factory UserModel.fromParseUser(ParseUser user) {
    return UserModel(
      objectId: user.objectId!,
      email: user.emailAddress!,
      username: user.username!,
      createdAt: user.createdAt ?? DateTime.now(),
      updatedAt: user.updatedAt ?? DateTime.now(),
    );
  }
}
