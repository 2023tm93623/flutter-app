import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import '../utils/constants.dart';

class RecordModel {
  final String objectId;
  final String name;
  final int age;
  final DateTime createdAt;
  final DateTime updatedAt;

  RecordModel({
    required this.objectId,
    required this.name,
    required this.age,
    required this.createdAt,
    required this.updatedAt,
  });

  factory RecordModel.fromParseObject(ParseObject parseObject) {
    return RecordModel(
      objectId: parseObject.objectId!,
      name: parseObject.get<String>(kRecordNameField) ?? '',
      age: parseObject.get<int>(kRecordAgeField) ?? 0,
      createdAt: parseObject.createdAt ?? DateTime.now(),
      updatedAt: parseObject.updatedAt ?? DateTime.now(),
    );
  }
}
