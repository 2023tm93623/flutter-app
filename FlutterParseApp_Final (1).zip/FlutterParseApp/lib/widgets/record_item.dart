import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

import '../models/record_model.dart';
import '../providers/record_provider.dart';
import '../screens/edit_record_screen.dart';

class RecordItem extends StatelessWidget {
  final RecordModel record;
  final Function? onDeleted;

  const RecordItem({
    Key? key,
    required this.record,
    this.onDeleted,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final recordProvider = Provider.of<RecordProvider>(context, listen: false);
    final dateFormat = DateFormat('MMM d, yyyy, h:mm a');

    return Card(
      elevation: 2,
      margin: EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        record.name,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Age: ${record.age}',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey[700],
                        ),
                      ),
                    ],
                  ),
                ),
                Row(
                  children: [
                    // Edit button
                    IconButton(
                      icon: Icon(Icons.edit, color: Colors.blue),
                      onPressed: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (ctx) => EditRecordScreen(
                              record: record,
                              onRecordUpdated: () {
                                // Add a slight delay to ensure the SnackBar shows after navigation
                                Future.delayed(Duration(milliseconds: 300), () {
                                  if (context.mounted) {
                                    ScaffoldMessenger.of(context)
                                        .clearSnackBars(); // Clear any existing SnackBars
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content:
                                            Text('Record updated successfully'),
                                        backgroundColor: Colors.green,
                                        behavior: SnackBarBehavior.floating,
                                        duration: Duration(seconds: 2),
                                      ),
                                    );
                                  }
                                });
                              },
                            ),
                          ),
                        );
                      },
                      tooltip: 'Edit',
                    ),
                    // Delete button
                    IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () {
                        _showDeleteConfirmDialog(context);
                      },
                      tooltip: 'Delete',
                    ),
                  ],
                ),
              ],
            ),

            SizedBox(height: 12),

            // Timestamp
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [],
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteConfirmDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Confirm Delete'),
        content: Text('Are you sure you want to delete this record?'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop();
            },
            child: Text('CANCEL'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.of(ctx).pop();

              final recordProvider = Provider.of<RecordProvider>(
                context,
                listen: false,
              );

              final success =
                  await recordProvider.deleteRecord(record.objectId);

              if (success && onDeleted != null) {
                onDeleted!();
              }
            },
            child: Text(
              'DELETE',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }
}
