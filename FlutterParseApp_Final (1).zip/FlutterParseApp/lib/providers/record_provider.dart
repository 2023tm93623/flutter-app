import 'package:flutter/material.dart';
import '../models/record_model.dart';
import '../services/record_service.dart';

enum RecordStatus {
  Initial,
  Loading,
  Loaded,
  Error,
}

class RecordProvider with ChangeNotifier {
  final RecordService _recordService = RecordService();
  
  RecordStatus _status = RecordStatus.Initial;
  List<RecordModel> _records = [];
  String? _errorMessage;
  
  // Getters
  RecordStatus get status => _status;
  List<RecordModel> get records => [..._records];
  String? get errorMessage => _errorMessage;
  bool get isLoading => _status == RecordStatus.Loading;
  
  Future<void> fetchRecords() async {
  // If already loading, don't start another request
  if (_status == RecordStatus.Loading) {
    return;
  }
  
  _status = RecordStatus.Loading;
  _errorMessage = null;
  notifyListeners();
  
  try {
    // Add timeout to prevent infinite loading
    _records = await _recordService.getAllRecords()
      .timeout(Duration(seconds: 10), onTimeout: () {
        throw Exception('Request timed out. Please try again.');
      });
    
    // Debug what we got back
    print("Fetched ${_records.length} records");
    
    _status = RecordStatus.Loaded;
    notifyListeners();
  } catch (error) {
    print("Error fetching records: $error");
    _status = RecordStatus.Error;
    _errorMessage = error.toString();
    notifyListeners();
    
    // Force to loaded state even with error to prevent endless spinner
    if (_records.isEmpty) {
      _records = [];
      _status = RecordStatus.Loaded;
      notifyListeners();
    }
  }
}
  
  // Add a new record
  Future<bool> addRecord(String name, int age) async {
    _status = RecordStatus.Loading;
    _errorMessage = null;
    notifyListeners();
    
    try {
      final newRecord = await _recordService.createRecord(name, age);
      _records.add(newRecord);
      _status = RecordStatus.Loaded;
      notifyListeners();
      return true;
    } catch (error) {
      _status = RecordStatus.Error;
      _errorMessage = error.toString();
      notifyListeners();
      return false;
    }
  }
  
  // Update an existing record
  Future<bool> updateRecord(String objectId, String name, int age) async {
    _status = RecordStatus.Loading;
    _errorMessage = null;
    notifyListeners();
    
    try {
      final updatedRecord = await _recordService.updateRecord(objectId, name, age);
      final index = _records.indexWhere((record) => record.objectId == objectId);
      
      if (index >= 0) {
        _records[index] = updatedRecord;
      }
      
      _status = RecordStatus.Loaded;
      notifyListeners();
      return true;
    } catch (error) {
      _status = RecordStatus.Error;
      _errorMessage = error.toString();
      notifyListeners();
      return false;
    }
  }
  
  // Delete a record
  Future<bool> deleteRecord(String objectId) async {
    _status = RecordStatus.Loading;
    _errorMessage = null;
    notifyListeners();
    
    try {
      await _recordService.deleteRecord(objectId);
      _records.removeWhere((record) => record.objectId == objectId);
      _status = RecordStatus.Loaded;
      notifyListeners();
      return true;
    } catch (error) {
      _status = RecordStatus.Error;
      _errorMessage = error.toString();
      notifyListeners();
      return false;
    }
  }
  
  // Get a record by ID
  RecordModel? getRecordById(String objectId) {
    return _records.firstWhere(
      (record) => record.objectId == objectId,
      orElse: () => RecordModel(
        objectId: '',
        name: '',
        age: 0,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ),
    );
  }
  
  // Clear error message
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}
