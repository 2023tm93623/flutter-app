import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';

enum AuthStatus {
  Unauthenticated,
  Authenticating,
  Authenticated,
  Error,
}

class AuthProvider with ChangeNotifier {
  final AuthService _authService = AuthService();
  
  AuthStatus _status = AuthStatus.Unauthenticated;
  UserModel? _user;
  String? _errorMessage;
  
  // Getters
  AuthStatus get status => _status;
  UserModel? get user => _user;
  String? get errorMessage => _errorMessage;
  bool get isAuthenticated => _status == AuthStatus.Authenticated;
  
  // Try to auto login the user
Future<bool> tryAutoLogin() async {
  if (_status == AuthStatus.Authenticating) {
    return false; // Already trying to authenticate
  }
  
  try {
    // First check if we have a user without making API calls
    _user = await _authService.getCurrentUser();
    
    if (_user != null) {
      _status = AuthStatus.Authenticated;
      notifyListeners();
      return true;
    }
    
    return false;
  } catch (error) {
    _status = AuthStatus.Unauthenticated;
    notifyListeners();
    return false;
  }
}
  
  // Sign up
  Future<bool> signUp(String username, String email, String password) async {
    _status = AuthStatus.Authenticating;
    _errorMessage = null;
    notifyListeners();
    
    try {
      _user = await _authService.signUp(username, email, password);
      _status = AuthStatus.Authenticated;
      notifyListeners();
      return true;
    } catch (error) {
      _status = AuthStatus.Error;
      _errorMessage = error.toString();
      notifyListeners();
      return false;
    }
  }
  
  // Login
  Future<bool> login(String username, String password) async {
    _status = AuthStatus.Authenticating;
    _errorMessage = null;
    notifyListeners();
    
    try {
      _user = await _authService.login(username, password);
      _status = AuthStatus.Authenticated;
      notifyListeners();
      return true;
    } catch (error) {
      _status = AuthStatus.Error;
      _errorMessage = error.toString();
      notifyListeners();
      return false;
    }
  }
  
  // Logout
  Future<void> logout() async {
    _status = AuthStatus.Authenticating;
    notifyListeners();
    
    try {
      await _authService.logout();
      _user = null;
      _status = AuthStatus.Unauthenticated;
      notifyListeners();
    } catch (error) {
      _status = AuthStatus.Error;
      _errorMessage = error.toString();
      notifyListeners();
    }
  }
  
  // Reset password
  Future<bool> resetPassword(String email) async {
    _status = AuthStatus.Authenticating;
    _errorMessage = null;
    notifyListeners();
    
    try {
      await _authService.resetPassword(email);
      _status = AuthStatus.Unauthenticated;
      notifyListeners();
      return true;
    } catch (error) {
      _status = AuthStatus.Error;
      _errorMessage = error.toString();
      notifyListeners();
      return false;
    }
  }
  
  // Clear error message
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}
